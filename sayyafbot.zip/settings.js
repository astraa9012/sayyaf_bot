// OBEY COMMANDMENTS

global.prefa = ['','!','.',',','🐤','🗿'] //NOT CHANGE
global.owner = ['62882000444707'] //OWNER
global.botname = 'ZuraBotz' //BOT NAME
global.versisc = "5.0.0" //NOT CHANGE
global.baileys1 = require('@whiskeysockets/baileys') //NOT CHANGE
global.creator = "AstraaLuckIsreal" //NOT CHANGE
global.packname = "Sticker By" //OPSIONAL
global.author = "ZuraBotz" //OPSIONAL
global.simbol = "" // SIMBOL MENU
global.idCH = null;
